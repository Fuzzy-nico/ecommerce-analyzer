
# Ecommerce Analyzer

Uno strumento rapido per analizzare siti ecommerce e ottenere insight di base come title, meta description e struttura HTML.
